<?php
// error_reporting(E_ALL);
// ini_set('display_errors', 1);
   require_once('./dbconnection.php');

   $db = db_connect();


   // Check if the form is submitted
   if (isset($_POST['insert'])) {
    // Retrieve form data
    $country = $_POST['country'];
    $city = $_POST['city'];
    $domain = $_POST['domain'];
    $company = $_POST['company'];
    $duration = $_POST['duration'];
    $description = $_POST['description'];
    $hourlyPaid = $_POST['hourly'];

    // Validate and sanitize the form data
    // (You can add your own validation logic here)

    // Insert the gig into the database
    $sql = "INSERT INTO gigs (country, city, domain, company, duration, description, hourly_paid)
            VALUES ('$country', '$city', '$domain', '$company', '$duration', '$description', '$hourlyPaid')";


    $result = $db->query($sql);

if ($result) {
    // Gig added successfully, redirect to displaygigs.php
    header('Location: displaygig.php');
    exit();
} else {
    echo "Error adding the gig: " . $db->error;
}
}   
?> 

<!DOCTYPE html>

<html>
<head>
    <title>Add Gig Form</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
        }

        .container {
            width: 80%;
            margin: 20px auto;
            padding: 20px;
            background-color: #f1f1f1;
            border: 1px solid #ccc;
        }

        h1 {
            text-align: center;
        }

        form {
            display: flex;
            flex-direction: column;
        }

        label {
            margin-bottom: 10px;
        }

        input[type="text"],
        input[type="number"],
        textarea {
            padding: 5px;
            margin-bottom: 10px;
        }

        input[type="submit"] {
            background-color: #4CAF50;
            color: white;
            padding: 10px 15px;
            border: none;
            cursor: pointer;
        }

        input[type="submit"]:hover {
            background-color: #45a049;
        }
    </style>
</head>
<body>
    
    <?php include 'navBar.php'; ?>

    <div class="container">
        <h1>Add Gig</h1>
        <form action="" method="POST">
            <label for="country">Country:</label>
            <input type="text" id="country" name="country" required>

            <label for="city">City:</label>
            <input type="text" id="city" name="city" required>

            <label for="domain">Domain:</label>
            <input type="text" id="domain" name="domain" required>

            <label for="company">Company Name:</label>
            <input type="text" id="company" name="company" required>

            <label for="duration">Duration:</label>
            <input type="text" id="duration" name="duration" required>

            <label for="description">Description:</label>
            <textarea id="description" name="description" required></textarea>

            <label for="hourly">Hourly Paid:</label>
            <input type="text" id="hourly" name="hourly" required>

            <input type="submit" value="Add Gig" name="insert">
        </form>
    </div>

    <?php include 'footer.php'; ?>
</body>
</html>

