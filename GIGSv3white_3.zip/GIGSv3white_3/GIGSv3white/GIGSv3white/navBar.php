<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="icon/icontitle.ico"/>
    <title></title>    
    <link rel="stylesheet" type="text/css" href="css/navBar.css">
    <link rel="stylesheet" type="text/css" href="css/footer.css">
    <script src="js/navBar.js"></script>

</head>
<body>
    
    <header>
        <nav> 
             
            <a href="firstpage.php"><img class="logo" src="icon/Flexygig_LOGO.jpg" width=90 height=50></a>      
            <a href="firstpage.php" class="icon"></a>
            <div class="mobileMenu">
                <div class="line1"></div>
                <div class="line2"></div>
                <div class="line3"></div>
            </div>
            <ul class="nav-list">
                <li><a href="./firstpage.php">Main</a></li>
                <li><a href="./about.php">About</a></li>
                <li><a href="./contact.php">Contact</a></li>
            </ul>
        </nav>
    </header>
   
</body>
</html>