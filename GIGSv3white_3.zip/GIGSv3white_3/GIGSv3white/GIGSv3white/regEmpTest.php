
<!DOCTYPE HTML>  
<html>
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta company_name$company_name="viewport" content="width=device-width, initial-scale=1.0">

    <link rel="stylesheet" href="images/"/>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=BioRhyme+Expanded:wght@300;700&display=swap" />
    <link rel="icon" href="icon/icontitle.ico"/>
    <title>Employer Register - GIGS</title>
<style>
.error {color: #FF0000;}
</style>
</head>
<body>  

<?php
// define variables and set to empty values
$company_nameErr = $emailErr = $phoneErr = $countryErr = $cityErr = $provinceErr = $passwordErr = $passwordConfirmationErr = "";
$company_name = $email = $phone = $country = $city = $province = $password = $passwordConfirmation = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
  if (empty($_POST["name"])) {
    $company_nameErr = "";
  } else {
    $company_name = test_input($_POST["name"]);
    // check if company_name$company_name only contains letters and whitespace
    if (!preg_match("/^[a-zA-Z-' ]*$/",$company_name)) {
      $company_nameErr = "Only letters and white space allowed";
    }
  }
  
  if (empty($_POST["email"])) {
    $emailErr = "";
  } else {
    $email = test_input($_POST["email"]);
    // check if e-mail address is well-formed
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
      $emailErr = "Invalid email format";
    }
  }

  if (empty($_POST["phone"])) {
    $phoneErr = "";
  } else {
    $phone = test_input($_POST["phone"]);
  }

  if (empty($_POST["country"])) {
    $countryErr = "";
  } else {
    $country = test_input($_POST["country"]);
  }
    
  if (empty($_POST["city"])) {
    $cityErr = "";
  } else {
    $city = test_input($_POST["city"]);
  }

  if (empty($_POST["province"])) {
    $provinceErr = "";
  } else {
    $province = test_input($_POST["province"]);
  }

  if (empty($_POST["province"])) {
    $provinceErr = "";
  } else {
    $province = test_input($_POST["province"]);
  }

  if (empty($_POST["password"])) {
    $passwordErr = "";
  } else{
    $password = test_input($_POST["password"]);
  }

  if (empty($_POST["password confirmation"])) {
    $passwordConfirmationErr = "";
  } else{
    $passwordConfirmation = test_input($_POST["password confirmation"]);
  }


}

function test_input($data) {
  $data = trim($data);
  $data = stripslashes($data);
  $data = htmlspecialchars($data);
  return $data;
}
?>

<h2>PHP Form Validation Example</h2><br>
<p><span class="error">* required field</span></p>
<form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">  
  Name: <input type="text" name="name" value="<?php echo $company_name;?>">
  <span class="error">* <?php echo $company_nameErr;?></span>
  <br><br>
  E-mail: <input type="email" name="email" value="<?php echo $email;?>">
  <span class="error">* <?php echo $emailErr;?></span>
  <br><br>
  Phone: <input type="text" name="phone" value="<?php echo $phone;?>">
  <span class="error">* <?php echo $phoneErr;?></span>
  <br><br>
  Country: <input type="text" name="country" value="<?php echo $country;?>">
  <span class="error">* <?php echo $countryErr;?></span>
  <br><br>
  City: <input type="text" name="city" value="<?php echo $city;?>">
  <span class="error">* <?php echo $cityErr;?></span>
  <br><br>
  Province: <input type="text" name="province" value="<?php echo $province;?>">
  <span class="error">* <?php echo $provinceErr;?></span>
  <br><br>
  Password: <input type="password" name="passowrd" value="<?php echo $password;?>">
  <span class="error">* <?php echo $passwordErr;?></span>
  <br><br>
  Confirm Password: <input type="password" name="password confirmation" value="<?php echo $phone;?>">
  <span class="error">* <?php echo $passwordConfirmationErr;?></span>
  <br><br>
  <input type="submit" name="submit" value="Submit">  
</form>


</body>
</html>