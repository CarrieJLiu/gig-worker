
<!DOCTYPE html>
<html>
<head>
    <title>Display Gigs</title>
    <style>
        /*
        PROJECT COLORS:
        #084D6A - DARK BLUE
        #48BEC5 - LIGHT BLUE
        #F0F1B7 - BEIGE
        #97D779 - GREEN
        */
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
        }

        .container {
            width: 80%;
            margin: 20px auto;
            padding: 20px;
            background-color: #f1f1f1;
            border: 1px solid #ccc;
        }

        h1 {
            text-align: center;
        }

        .gig {
            margin-bottom: 20px;
            padding: 10px;
            background-color: #f9f9f9;
            border: 1px solid #ddd;
        }

        .gig:nth-child(even) {
            background-color: #f1f1f1;
        }

        .gig h3 {
            margin: 0;
            font-size: 18px;
        }

        .gig p {
            margin: 5px 0;
        }

        #addgig, #chat, #review, #delete{
            border-radius: 5px;
            padding: 3px 12px;
            font-weight: 800;
            font-size: 18px;
            border: none;
            background-color: #084D6A;
            color: #97D779;
            cursor: pointer;
        }

      

    </style>
</head>
<body>
    <?php include 'navBar.php'; ?>

    <div class="container">
        <a href="addform.php"><button id="addgig">Add1 Gig</button></a>
        <a href="../newchat/indexchat.html" target="_blank"><button id="chat">Chat</button></a>
        <a href="./review.php" target="_blank"><button id="review">Review</button></a>

        <?php
        require_once('./dbconnection.php');

        $db = db_connect();


            echo '<div class="gig-container">';

            // Fetch gigs from the database
            $sql = "SELECT * FROM gigs ORDER BY id DESC";
            $result = $db->query($sql);

            // Display the gigs
            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    echo '<li class="gig">';
                    echo '<h3>' . $row['company'] . '</h3>';
                    echo '<p>Location: ' . $row['city'] . ', ' . $row['country'] . '</p>';
                    echo '<p>Domain: ' . $row['domain'] . '</p>';
                    echo '<p>Duration: ' . $row['duration'] . '</p>';
                    echo '<p>Description: ' . $row['description'] . '</p>';
                    echo '<p>Hourly Paid: $' . $row['hourly_paid'] . '</p>';
                 
                    echo '<a href="../newchat/indexchat.html" target="_blank"><button id="chat">Chat1</button></a>';

                    echo '<button class="delete-button" data-id="  ' . $row['id'] . '" target="_blank" id="delete">Delete</button>';

                    //add edit button so I can edit the information ((company, city, domin, duration,description, hourly_paid) in same page
                    // echo '<button class="edit-button" data-id="' . $row['id'] . '">Edit</button>';

                    echo '<a href="./review.php" target="_blank"><button id="review">Review</button></a>';
                    echo '</li>';
                }
            } else {
                echo "No gigs added yet.";
            }
            echo '</div>';
            //
            db_disconnect($db);

        ?>
        
       

    </div>

    <?php include 'footer.php'; ?>

    <script>
    // Get all delete buttons by their class name
    const deleteButtons = document.getElementsByClassName('delete-button');

    // Attach click event listener to each delete button
    Array.from(deleteButtons).forEach(button => {
        button.addEventListener('click', deleteGig);
    });

    // Function to handle the delete button click event
    function deleteGig(event) {
        const gigId = event.target.dataset.id; // Get the gig ID from the data-id attribute
        const confirmation = confirm("Are you sure you want to delete this gig?");

        if (confirmation) {
            // Send a POST request to delete.php to delete the gig
            fetch('delete.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: `id=${gigId}`,
            })
                .then(response => response.text())
                .then(result => {
                    console.log(result); // You can handle the response here if needed
                    // Update the gig list after successful deletion
                    event.target.closest('.gig').remove();
                })
                .catch(error => console.error(error));
        }
    }

        </script>


</body>
</html>
