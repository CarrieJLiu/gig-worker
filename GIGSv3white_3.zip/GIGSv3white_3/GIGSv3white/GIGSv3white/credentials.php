
<?php
//Credentials needed to access the database.
define("serverName", "localhost");
define("dBUserName", "root");
define("dBPassword", "");
define("dBName", "project1");
?>
